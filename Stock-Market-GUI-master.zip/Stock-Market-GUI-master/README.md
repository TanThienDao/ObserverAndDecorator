# Stock-Market-GUI
A GUI to show stock data approach by JAVA Swing and Graphics2D. 
The readme is in the comments of each script. Looks not bad, emmmmm...


![image](Screenshots/p0.png)


![image](Screenshots/p1.png)
