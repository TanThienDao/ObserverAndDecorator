package com.company;

abstract class Observer2 {
    public abstract void update(int value);
}
