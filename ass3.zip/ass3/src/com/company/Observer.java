package com.company;

public interface Observer {
    public abstract void update(int value);


}
