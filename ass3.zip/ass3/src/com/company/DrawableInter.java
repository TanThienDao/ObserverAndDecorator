package com.company;

import java.awt.*;

public interface DrawableInter {
    public void draw(Graphics g);
}
