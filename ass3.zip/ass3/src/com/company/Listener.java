package com.company;

import java.awt.event.ActionEvent;

public interface Listener {
    public void actionPerformed(ActionEvent e);
}
